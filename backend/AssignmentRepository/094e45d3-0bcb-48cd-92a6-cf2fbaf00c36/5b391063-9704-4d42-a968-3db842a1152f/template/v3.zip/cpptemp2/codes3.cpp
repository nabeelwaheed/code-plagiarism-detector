#include <iostream>
using namespace std;

void inputGrades(int grades[], int size);
double calculateAverage(int grades[], int size);
int findHighest(int grades[], int size);
int findLowest(int grades[], int size);
void displayGrades(int grades[], int size);

int main() {
    int grades[50];
    int n;

    cout << "Enter number of students: ";
    cin >> n;

    inputGrades(grades, n);

    double avg = calculateAverage(grades, n);
    int high = findHighest(grades, n);
    int low = findLowest(grades, n);

    displayGrades(grades, n);

    cout << "Average Grade: " << avg << endl;
    cout << "Highest Grade: " << high << endl;
    cout << "Lowest Grade: " << low << endl;

    return 0;
}

void inputGrades(int grades[], int size) {
    for(int i = 0; i < size; i++) {
        cout << "Enter grade for student " << i + 1 << ": ";
        cin >> grades[i];
    }
}

double calculateAverage(int grades[], int size) {
    int sum = 0;
    for(int i = 0; i < size; i++) {
        sum += grades[i];
    }
    return (double)sum / size;
}

int findHighest(int grades[], int size) {
    int max = grades[0];
    for(int i = 1; i < size; i++) {
        if(grades[i] > max) {
            max = grades[i];
        }
    }
    return max;
}

int findLowest(int grades[], int size) {
    int min = grades[0];
    for(int i = 1; i < size; i++) {
        if(grades[i] < min) {
            min = grades[i];
        }
    }
    return min;
}

void displayGrades(int grades[], int size) {
    cout << "Grades: ";
    for(int i = 0; i < size; i++) {
        cout << grades[i] << " ";
    }
    cout << endl;
}