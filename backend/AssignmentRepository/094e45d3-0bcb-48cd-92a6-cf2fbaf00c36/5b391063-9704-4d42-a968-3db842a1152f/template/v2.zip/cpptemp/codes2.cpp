#include <iostream>
using namespace std;

int main() {
    cout << "cheeseburger" << endl;
    cout << "cheeseburger" << endl;
    cout << "cheeseburger" << endl;
    cout << "cheeseburger" << endl;
    cout << "cheeseburger" << endl;
    return 0;
}