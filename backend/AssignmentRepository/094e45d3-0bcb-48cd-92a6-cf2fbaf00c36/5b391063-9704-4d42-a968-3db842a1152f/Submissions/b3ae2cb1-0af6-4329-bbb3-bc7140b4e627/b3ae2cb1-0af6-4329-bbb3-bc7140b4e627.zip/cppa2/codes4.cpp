#include <iostream>
using namespace std;

void inputTemperatures(double temps[], int size);
double calculateAverageTemp(double temps[], int size);
double findHighestTemp(double temps[], int size);
double findLowestTemp(double temps[], int size);
void displayTemperatures(double temps[], int size);

int main() {
    double temps[50];
    int n;

    cout << "Enter number of days: ";
    cin >> n;

    inputTemperatures(temps, n);

    double avg = calculateAverageTemp(temps, n);
    double high = findHighestTemp(temps, n);
    double low = findLowestTemp(temps, n);

    displayTemperatures(temps, n);

    cout << "Average Temperature: " << avg << endl;
    cout << "Highest Temperature: " << high << endl;
    cout << "Lowest Temperature: " << low << endl;

    return 0;
}

void inputTemperatures(double temps[], int size) {
    for(int i = 0; i < size; i++) {
        cout << "Enter temperature for day " << i + 1 << ": ";
        cin >> temps[i];
    }
}

double calculateAverageTemp(double temps[], int size) {
    double sum = 0;
    for(int i = 0; i < size; i++) {
        sum += temps[i];
    }
    return sum / size;
}

double findHighestTemp(double temps[], int size) {
    double max = temps[0];
    for(int i = 1; i < size; i++) {
        if(temps[i] > max) {
            max = temps[i];
        }
    }
    return max;
}

double findLowestTemp(double temps[], int size) {
    double min = temps[0];
    for(int i = 1; i < size; i++) {
        if(temps[i] < min) {
            min = temps[i];
        }
    }
    return min;
}

void displayTemperatures(double temps[], int size) {
    cout << "Temperatures: ";
    for(int i = 0; i < size; i++) {
        cout << temps[i] << " ";
    }
    cout << endl;
}