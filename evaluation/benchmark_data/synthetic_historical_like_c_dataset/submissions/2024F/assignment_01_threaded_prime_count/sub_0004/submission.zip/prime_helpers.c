#include "template.h"

int is_prime_number(int n) {
    if (n < 2) return 0;
    for (int factor = 2; factor * factor <= n; ++factor) {
        if (n % factor == 0) return 0;
    }
    return 1;
}

void* run_chunk(void* arg) {
    WorkChunk* chunk = (WorkChunk*)arg;
    int seen = 0;
    for (int v = chunk->start; v <= chunk->end; ++v) {
        if (is_prime_number(v)) seen++;
    }
    chunk->partial_count = seen;
    return NULL;
}
