#include "template.h"

int is_prime_number(int n);
void* run_chunk(void* arg);

int main(int argc, char** argv) {
    if (argc != 4) {
        print_usage();
        return 1;
    }

    int start = atoi(argv[1]);
    int end = atoi(argv[2]);
    int threads = atoi(argv[3]);
    if (threads < 1 || end < start) return 2;

    pthread_t tids[16];
    WorkChunk chunks[16];
    int width = (end - start + 1) / threads;
    int cursor = start;
    int total = 0;

    for (int i = 0; i < threads; ++i) {
        chunks[i].start = cursor;
        chunks[i].end = (i == threads - 1) ? end : (cursor + width - 1);
        chunks[i].partial_count = 0;
        cursor = chunks[i].end + 1;
        pthread_create(&tids[i], NULL, run_chunk, &chunks[i]);
    }

    for (int i = 0; i < threads; ++i) {
        pthread_join(tids[i], NULL);
        total += chunks[i].partial_count;
    }

    printf("%d\n", total);
    return 0;
}
