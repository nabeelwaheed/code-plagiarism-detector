#include "template.h"

static int is_prime(int n) {
    if (n < 2) return 0;
    for (int d = 2; d * d <= n; ++d) {
        if (n % d == 0) return 0;
    }
    return 1;
}

static void* worker(void* arg) {
    WorkChunk* chunk = (WorkChunk*)arg;
    int total = 0;
    for (int x = chunk->start; x <= chunk->end; ++x) {
        if (is_prime(x)) total++;
    }
    chunk->partial_count = total;
    return NULL;
}

int main(int argc, char** argv) {
    if (argc != 4) {
        print_usage();
        return 1;
    }
    int start = atoi(argv[1]);
    int end = atoi(argv[2]);
    int threads = atoi(argv[3]);
    if (threads < 1 || end < start) return 2;

    pthread_t tids[16];
    WorkChunk chunks[16];
    int width = (end - start + 1) / threads;
    int cursor = start;
    int total = 0;

    for (int i = 0; i < threads; ++i) {
        chunks[i].start = cursor;
        chunks[i].end = (i == threads - 1) ? end : (cursor + width - 1);
        chunks[i].partial_count = 0;
        cursor = chunks[i].end + 1;
        pthread_create(&tids[i], NULL, worker, &chunks[i]);
    }

    for (int i = 0; i < threads; ++i) {
        pthread_join(tids[i], NULL);
        total += chunks[i].partial_count;
    }

    printf("%d\n", total);
    return 0;
}
