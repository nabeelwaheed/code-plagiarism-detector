#include "template.h"

static int sieve_count(int start, int end) {
    if (end < 2) return 0;
    int size = end + 1;
    char* mark = calloc((size_t)size, sizeof(char));
    int count = 0;
    for (int i = 2; i <= end; ++i) mark[i] = 1;
    for (int p = 2; p * p <= end; ++p) {
        if (mark[p]) {
            for (int k = p * p; k <= end; k += p) mark[k] = 0;
        }
    }
    for (int i = start < 2 ? 2 : start; i <= end; ++i) {
        if (mark[i]) count++;
    }
    free(mark);
    return count;
}

int main(int argc, char** argv) {
    if (argc != 4) {
        print_usage();
        return 1;
    }
    int start = atoi(argv[1]);
    int end = atoi(argv[2]);
    (void)atoi(argv[3]);
    if (end < start) return 2;
    printf("%d\n", sieve_count(start, end));
    return 0;
}
