#include "template.h"

static double average_marks(int* marks, int n) {
    int sum = 0;
    for (int i = 0; i < n; ++i) sum += marks[i];
    return (double)sum / (double)n;
}

int main(void) {
    StudentRecord row;
    print_header();
    while (scanf("%63[^,],%d,%d,%d,%d\n",
                 row.name,
                 &row.marks[0],
                 &row.marks[1],
                 &row.marks[2],
                 &row.marks[3]) == 5) {
        row.average = average_marks(row.marks, 4);
        printf("%s,%.2f\n", row.name, row.average);
    }
    return 0;
}
