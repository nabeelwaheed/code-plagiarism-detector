#include "template.h"

static int parse_record(char* line, StudentRecord* out) {
    char* token = strtok(line, ",");
    if (!token) return 0;
    strncpy(out->name, token, sizeof(out->name) - 1);
    out->name[sizeof(out->name) - 1] = '\0';

    int sum = 0;
    for (int i = 0; i < 4; ++i) {
        token = strtok(NULL, ",");
        if (!token) return 0;
        out->marks[i] = atoi(token);
        sum += out->marks[i];
    }
    out->average = (double)sum / 4.0;
    return 1;
}

int main(void) {
    char line[256];
    StudentRecord current;
    print_header();
    while (fgets(line, sizeof(line), stdin)) {
        if (parse_record(line, &current)) {
            printf("%s,%.2f\n", current.name, current.average);
        }
    }
    return 0;
}
