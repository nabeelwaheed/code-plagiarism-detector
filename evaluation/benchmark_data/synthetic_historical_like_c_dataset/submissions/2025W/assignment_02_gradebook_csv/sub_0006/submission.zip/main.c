#include "template.h"

static double compute_avg(const int values[4]) {
    int total = values[0] + values[1] + values[2] + values[3];
    return (double) total / 4.0;
}

int main(void) {
    StudentRecord entry;
    print_header();

    while (scanf("%63[^,],%d,%d,%d,%d\n",
                 entry.name,
                 &entry.marks[0],
                 &entry.marks[1],
                 &entry.marks[2],
                 &entry.marks[3]) == 5) {
        entry.average = compute_avg(entry.marks);
        printf("%s,%.2f\n", entry.name, entry.average);
    }

    return 0;
}
