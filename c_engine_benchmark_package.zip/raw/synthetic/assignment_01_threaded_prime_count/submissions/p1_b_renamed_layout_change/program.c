#include "prime_template.h"
#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

static int prime_flag(int x) {
    if (x < 2) return 0;
    if (x == 2) return 1;
    if ((x & 1) == 0) return 0;

    int edge = (int)sqrt((double)x);
    for (int div = 3; div <= edge; div += 2) {
        if (x % div == 0) {
            return 0;
        }
    }
    return 1;
}

static void *worker_body(void *ptr) {
    WorkItem *job = (WorkItem *)ptr;
    int local_total = 0;
    for (int value = job->start; value <= job->end; ++value) {
        local_total += prime_flag(value);
    }
    job->result = local_total;
    return NULL;
}

int main(int argc, char **argv) {
    int upper = 0;
    int workers = 0;
    parse_args(argc, argv, &upper, &workers);

    WorkItem *jobs = calloc((size_t)workers, sizeof(WorkItem));
    pthread_t *handles = calloc((size_t)workers, sizeof(pthread_t));
    if (jobs == NULL || handles == NULL) {
        fprintf(stderr, "allocation failed\n");
        return 2;
    }

    split_range(upper, workers, jobs);

    for (int i = 0; i < workers; ++i) {
        pthread_create(&handles[i], NULL, worker_body, jobs + i);
    }

    int answer = 0;
    for (int i = 0; i < workers; ++i) {
        pthread_join(handles[i], NULL);
        answer += jobs[i].result;
    }

    printf("%d\n", answer);
    free(handles);
    free(jobs);
    return 0;
}
