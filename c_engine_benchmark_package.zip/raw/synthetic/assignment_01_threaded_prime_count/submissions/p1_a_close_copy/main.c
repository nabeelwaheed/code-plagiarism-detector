#include "prime_template.h"
#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

static int is_prime_number(int value) {
    if (value < 2) return 0;
    if (value == 2) return 1;
    if (value % 2 == 0) return 0;
    int limit = (int)sqrt((double)value);
    for (int candidate = 3; candidate <= limit; candidate += 2) {
        if (value % candidate == 0) return 0;
    }
    return 1;
}

static void *count_worker(void *raw) {
    WorkItem *item = (WorkItem *)raw;
    int matches = 0;
    for (int n = item->start; n <= item->end; ++n) {
        if (is_prime_number(n)) {
            matches++;
        }
    }
    item->result = matches;
    return NULL;
}

int main(int argc, char **argv) {
    int range_end = 0;
    int thread_count = 0;
    parse_args(argc, argv, &range_end, &thread_count);

    WorkItem *items = calloc((size_t)thread_count, sizeof(WorkItem));
    pthread_t *threads = calloc((size_t)thread_count, sizeof(pthread_t));
    if (!items || !threads) {
        fprintf(stderr, "allocation failed\n");
        return 2;
    }

    split_range(range_end, thread_count, items);
    for (int i = 0; i < thread_count; ++i) {
        pthread_create(&threads[i], NULL, count_worker, &items[i]);
    }

    int total = 0;
    for (int i = 0; i < thread_count; ++i) {
        pthread_join(threads[i], NULL);
        total += items[i].result;
    }

    printf("%d\n", total);
    free(threads);
    free(items);
    return 0;
}
