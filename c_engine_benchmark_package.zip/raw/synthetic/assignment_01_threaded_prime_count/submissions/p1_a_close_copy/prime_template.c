#include "prime_template.h"
#include <stdio.h>
#include <stdlib.h>

void parse_args(int argc, char **argv, int *range_end, int *threads) {
    if (argc < 3) {
        fprintf(stderr, "usage: %s <range_end> <threads>\n", argv[0]);
        exit(1);
    }
    *range_end = atoi(argv[1]);
    *threads = atoi(argv[2]);
    if (*range_end < 2 || *threads < 1) {
        fprintf(stderr, "invalid arguments\n");
        exit(1);
    }
}

void split_range(int range_end, int threads, WorkItem *items) {
    int base = range_end / threads;
    int extra = range_end % threads;
    int cursor = 1;
    for (int i = 0; i < threads; ++i) {
        int size = base + (i < extra ? 1 : 0);
        items[i].start = cursor;
        items[i].end = cursor + size - 1;
        items[i].result = 0;
        cursor += size;
    }
}
