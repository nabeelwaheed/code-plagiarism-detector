#ifndef PRIME_TEMPLATE_H
#define PRIME_TEMPLATE_H

#include <pthread.h>
#include <stddef.h>

typedef struct {
    int start;
    int end;
    int result;
} WorkItem;

void parse_args(int argc, char **argv, int *range_end, int *threads);
void split_range(int range_end, int threads, WorkItem *items);

#endif
