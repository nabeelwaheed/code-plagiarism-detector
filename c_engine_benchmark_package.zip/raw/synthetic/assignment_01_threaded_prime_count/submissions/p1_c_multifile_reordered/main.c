#include "prime_template.h"
#include "worker.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    int limit = 0;
    int threads = 0;
    parse_args(argc, argv, &limit, &threads);

    WorkItem *parts = calloc((size_t)threads, sizeof(WorkItem));
    pthread_t *ids = calloc((size_t)threads, sizeof(pthread_t));
    if (!parts || !ids) {
        fprintf(stderr, "allocation failed\n");
        return 2;
    }

    split_range(limit, threads, parts);

    for (int i = 0; i < threads; ++i) {
        pthread_create(&ids[i], NULL, run_prime_counter, &parts[i]);
    }

    int total = 0;
    for (int i = 0; i < threads; ++i) {
        pthread_join(ids[i], NULL);
        total += parts[i].result;
    }

    printf("%d\n", total);
    free(ids);
    free(parts);
    return 0;
}
