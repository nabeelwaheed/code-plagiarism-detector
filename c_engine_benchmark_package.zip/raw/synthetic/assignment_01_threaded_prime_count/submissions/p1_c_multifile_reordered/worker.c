#include "worker.h"
#include <math.h>

int check_prime(int value) {
    if (value < 2) return 0;
    if (value == 2) return 1;
    if (value % 2 == 0) return 0;
    int stop = (int)sqrt((double)value);
    for (int i = 3; i <= stop; i += 2) {
        if (value % i == 0) return 0;
    }
    return 1;
}

void *run_prime_counter(void *raw) {
    WorkItem *slot = (WorkItem *)raw;
    int count = 0;
    for (int n = slot->start; n <= slot->end; ++n) {
        if (check_prime(n)) {
            count++;
        }
    }
    slot->result = count;
    return NULL;
}
