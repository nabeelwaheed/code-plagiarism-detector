#ifndef WORKER_H
#define WORKER_H

#include "prime_template.h"
void *run_prime_counter(void *raw);
int check_prime(int value);

#endif
