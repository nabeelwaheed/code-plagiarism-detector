#include "prime_template.h"
#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int limit;
    int next_value;
    int hits;
    pthread_mutex_t lock;
} SharedState;

static int is_prime_slow(int value) {
    if (value < 2) return 0;
    if (value == 2) return 1;
    if (value % 2 == 0) return 0;
    for (int d = 3; d <= (int)sqrt((double)value); d += 2) {
        if (value % d == 0) return 0;
    }
    return 1;
}

static void *queue_worker(void *raw) {
    SharedState *state = (SharedState *)raw;
    int local = 0;
    while (1) {
        int candidate = 0;
        pthread_mutex_lock(&state->lock);
        if (state->next_value > state->limit) {
            pthread_mutex_unlock(&state->lock);
            break;
        }
        candidate = state->next_value;
        state->next_value += 1;
        pthread_mutex_unlock(&state->lock);

        if (is_prime_slow(candidate)) {
            local++;
        }
    }

    pthread_mutex_lock(&state->lock);
    state->hits += local;
    pthread_mutex_unlock(&state->lock);
    return NULL;
}

int main(int argc, char **argv) {
    int upper = 0;
    int workers = 0;
    parse_args(argc, argv, &upper, &workers);

    SharedState state;
    state.limit = upper;
    state.next_value = 1;
    state.hits = 0;
    pthread_mutex_init(&state.lock, NULL);

    pthread_t *ids = calloc((size_t)workers, sizeof(pthread_t));
    if (!ids) {
        fprintf(stderr, "allocation failed\n");
        return 2;
    }

    for (int i = 0; i < workers; ++i) {
        pthread_create(&ids[i], NULL, queue_worker, &state);
    }
    for (int i = 0; i < workers; ++i) {
        pthread_join(ids[i], NULL);
    }

    printf("%d\n", state.hits);
    pthread_mutex_destroy(&state.lock);
    free(ids);
    return 0;
}
