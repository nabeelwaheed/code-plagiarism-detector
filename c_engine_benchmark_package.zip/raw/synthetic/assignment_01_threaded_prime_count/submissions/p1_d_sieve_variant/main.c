#include "prime_template.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int start_index;
    int end_index;
    char *mark;
    int total;
} CountTask;

static void *sum_chunk(void *raw) {
    CountTask *task = (CountTask *)raw;
    int local = 0;
    for (int i = task->start_index; i <= task->end_index; ++i) {
        if (task->mark[i]) {
            local++;
        }
    }
    task->total = local;
    return NULL;
}

static void build_sieve(char *mark, int n) {
    memset(mark, 1, (size_t)(n + 1));
    mark[0] = 0;
    mark[1] = 0;
    for (int p = 2; p * p <= n; ++p) {
        if (!mark[p]) continue;
        for (int k = p * p; k <= n; k += p) {
            mark[k] = 0;
        }
    }
}

int main(int argc, char **argv) {
    int range_end = 0;
    int thread_count = 0;
    parse_args(argc, argv, &range_end, &thread_count);

    char *mark = malloc((size_t)range_end + 1);
    CountTask *tasks = calloc((size_t)thread_count, sizeof(CountTask));
    pthread_t *threads = calloc((size_t)thread_count, sizeof(pthread_t));
    if (!mark || !tasks || !threads) {
        fprintf(stderr, "allocation failed\n");
        return 2;
    }

    build_sieve(mark, range_end);

    int base = range_end / thread_count;
    int extra = range_end % thread_count;
    int cursor = 1;
    for (int i = 0; i < thread_count; ++i) {
        int size = base + (i < extra ? 1 : 0);
        tasks[i].start_index = cursor;
        tasks[i].end_index = cursor + size - 1;
        tasks[i].mark = mark;
        tasks[i].total = 0;
        cursor += size;
        pthread_create(&threads[i], NULL, sum_chunk, &tasks[i]);
    }

    int total = 0;
    for (int i = 0; i < thread_count; ++i) {
        pthread_join(threads[i], NULL);
        total += tasks[i].total;
    }

    printf("%d\n", total);
    free(threads);
    free(tasks);
    free(mark);
    return 0;
}
