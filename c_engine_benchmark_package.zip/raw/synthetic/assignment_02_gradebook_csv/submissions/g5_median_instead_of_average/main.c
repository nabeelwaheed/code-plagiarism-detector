#include "gradebook_template.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int find_or_add(StudentRow *rows, int *count, const char *name) {
    for (int i = 0; i < *count; ++i) {
        if (strcmp(rows[i].name, name) == 0) {
            return i;
        }
    }
    strcpy(rows[*count].name, name);
    rows[*count].used = 0;
    return (*count)++;
}

static int cmp_int(const void *a, const void *b) {
    return (*(const int *)a) - (*(const int *)b);
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: %s <csv>\n", argv[0]);
        return 1;
    }

    FILE *fp = open_input(argv[1]);
    StudentRow rows[32] = {0};
    int count = 0;
    char line[128];

    while (fgets(line, sizeof(line), fp)) {
        char name[64];
        int score = 0;
        if (!parse_line(line, name, &score)) {
            continue;
        }
        int index = find_or_add(rows, &count, name);
        rows[index].scores[rows[index].used++] = score;
    }

    for (int i = 0; i < count; ++i) {
        qsort(rows[i].scores, (size_t)rows[i].used, sizeof(int), cmp_int);
        int mid = rows[i].used / 2;
        int value = rows[i].used % 2 == 0
            ? (rows[i].scores[mid - 1] + rows[i].scores[mid]) / 2
            : rows[i].scores[mid];
        printf("%s,%d\n", rows[i].name, value);
    }

    fclose(fp);
    return 0;
}
