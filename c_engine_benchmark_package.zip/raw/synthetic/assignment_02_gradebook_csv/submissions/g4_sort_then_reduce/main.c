#include "gradebook_template.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char name[64];
    int score;
} Entry;

static int cmp_entry(const void *left, const void *right) {
    const Entry *a = (const Entry *)left;
    const Entry *b = (const Entry *)right;
    return strcmp(a->name, b->name);
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: %s <csv>\n", argv[0]);
        return 1;
    }

    FILE *fp = open_input(argv[1]);
    Entry entries[64];
    int count = 0;
    char line[128];

    while (fgets(line, sizeof(line), fp) != NULL) {
        if (!parse_line(line, entries[count].name, &entries[count].score)) {
            continue;
        }
        count++;
    }

    qsort(entries, (size_t)count, sizeof(Entry), cmp_entry);

    int i = 0;
    while (i < count) {
        int total = 0;
        int used = 0;
        int j = i;
        while (j < count && strcmp(entries[i].name, entries[j].name) == 0) {
            total += entries[j].score;
            used++;
            j++;
        }
        printf("%s,%d\n", entries[i].name, total / used);
        i = j;
    }

    fclose(fp);
    return 0;
}
