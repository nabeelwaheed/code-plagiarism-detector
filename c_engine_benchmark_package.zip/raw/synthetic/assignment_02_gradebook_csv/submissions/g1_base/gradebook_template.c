#include "gradebook_template.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE *open_input(const char *path) {
    FILE *fp = fopen(path, "r");
    if (!fp) {
        perror("fopen");
        exit(1);
    }
    return fp;
}

int parse_line(char *line, char *name_out, int *score_out) {
    char *comma = strchr(line, ',');
    if (!comma) {
        return 0;
    }
    *comma = '\0';
    strcpy(name_out, line);
    *score_out = atoi(comma + 1);
    return 1;
}
