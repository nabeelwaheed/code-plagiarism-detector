#ifndef GRADEBOOK_TEMPLATE_H
#define GRADEBOOK_TEMPLATE_H

#include <stdio.h>

typedef struct {
    char name[64];
    int scores[8];
    int used;
} StudentRow;

FILE *open_input(const char *path);
int parse_line(char *line, char *name_out, int *score_out);

#endif
