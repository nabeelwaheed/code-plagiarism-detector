#ifndef ROWS_H
#define ROWS_H

#include "gradebook_template.h"
int get_slot(StudentRow *rows, int *count, const char *name);
int compute_average(const StudentRow *row);

#endif
