#include "gradebook_template.h"
#include "rows.h"
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: %s <csv>\n", argv[0]);
        return 1;
    }

    StudentRow rows[32] = {0};
    int count = 0;
    char line[128];
    FILE *fp = open_input(argv[1]);

    while (fgets(line, sizeof(line), fp)) {
        char name[64];
        int score = 0;
        if (!parse_line(line, name, &score)) {
            continue;
        }
        int slot = get_slot(rows, &count, name);
        rows[slot].scores[rows[slot].used++] = score;
    }

    for (int i = 0; i < count; ++i) {
        printf("%s,%d\n", rows[i].name, compute_average(&rows[i]));
    }

    fclose(fp);
    return 0;
}
