#include "rows.h"
#include <string.h>

int get_slot(StudentRow *rows, int *count, const char *name) {
    for (int i = 0; i < *count; ++i) {
        if (strcmp(rows[i].name, name) == 0) {
            return i;
        }
    }
    strcpy(rows[*count].name, name);
    rows[*count].used = 0;
    return (*count)++;
}

int compute_average(const StudentRow *row) {
    int total = 0;
    for (int i = 0; i < row->used; ++i) {
        total += row->scores[i];
    }
    return row->used == 0 ? 0 : total / row->used;
}
