#include "gradebook_template.h"
#include <stdio.h>
#include <string.h>

static int locate(StudentRow *items, int *used, const char *student) {
    for (int i = 0; i < *used; ++i) {
        if (strcmp(items[i].name, student) == 0) {
            return i;
        }
    }
    strcpy(items[*used].name, student);
    items[*used].used = 0;
    return (*used)++;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: %s <csv>\n", argv[0]);
        return 1;
    }

    StudentRow items[32] = {0};
    int used = 0;
    char buffer[128];
    FILE *input = open_input(argv[1]);

    while (fgets(buffer, sizeof(buffer), input) != NULL) {
        char who[64];
        int mark = 0;
        if (!parse_line(buffer, who, &mark)) {
            continue;
        }
        int slot = locate(items, &used, who);
        items[slot].scores[items[slot].used++] = mark;
    }

    for (int i = 0; i < used; ++i) {
        int sum = 0;
        for (int j = 0; j < items[i].used; ++j) {
            sum += items[i].scores[j];
        }
        printf("%s,%d\n", items[i].name, sum / items[i].used);
    }

    fclose(input);
    return 0;
}
