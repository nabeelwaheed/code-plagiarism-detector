# Benchmark design notes

## Design goals
- Mirror the SRS upload path with zip-based fixtures
- Keep tests assignment-organized
- Separate template overlap from student-authored overlap
- Include near-copies, obfuscated near-copies, alternative algorithms, and negatives

## Positive classes
- renamed identifiers
- formatting/layout changes
- reordered helper functions
- multifile reorganization
- minor structural disguises

## Negative classes
- same assignment, different algorithm
- same template, materially different student logic
- cross-assignment controls

## Security fixture
- `invalid_zip_slip_example.zip` contains a `../evil.c` entry
- use it only if archive extraction lives in or near the engine ingestion boundary

## Limitation
Synthetic benchmark results are useful for regression testing and provisional calibration, but they are not a substitute for anonymized historical validation.
