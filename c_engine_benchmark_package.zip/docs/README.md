# C engine benchmark starter package

This package is a repo-agnostic starter benchmark for a C similarity engine.

## What is included
- zip-first synthetic submissions
- template archives for mandatory template subtraction
- labeled benchmark pairs for review-threshold calibration
- cross-assignment negative controls
- an invalid zip-slip archive for ingestion/security tests
- import schemas for future anonymized historical data

## Why zip-first
The SRS says normal student submissions can be a single file or a zip archive with multiple files, and instructor templates are zip archives. This package therefore treats zip archives as the primary engine-facing fixture format.

## Assignments included
1. `assignment_01_threaded_prime_count`
   - concurrency-oriented C submissions
   - includes near-copies, renamed variants, multifile variants, and lower-similarity alternative algorithms
2. `assignment_02_gradebook_csv`
   - file-processing C submissions
   - includes near-copies, multifile variants, alternative algorithms, and template-heavy negatives

## Benchmark files
- `benchmark_pairs.json`
- `benchmark_pairs.csv`
- `submissions_manifest.json`

## Label semantics
`should_flag_for_review=true` means the pair is intended as a positive benchmark example for triage/review, not an automatic plagiarism verdict.

## Suggested Codex use
Ask Codex to:
1. inspect the repo for the current C-engine entry point
2. adapt the evaluation runner to this benchmark format
3. run threshold sweeps against `benchmark_pairs.json`
4. keep changes isolated to engine/evaluation/scripts/tests

## Notes
This package is synthetic. It supports an honest provisional benchmark, not a historical-validity claim.
