You now have a benchmark package prepared outside the repo. Use it to implement the C-engine evaluation layer without disturbing the front-end or main back-end.

Package location assumptions:
- benchmark root: `c_engine_benchmark_package/`
- pair labels: `c_engine_benchmark_package/benchmark_pairs.json`
- schemas: `c_engine_benchmark_package/schema/`
- docs: `c_engine_benchmark_package/docs/`
- archives: `c_engine_benchmark_package/archives/`

Hard constraints
- Do not modify front-end unless absolutely unavoidable.
- Do not modify main API/backend unless absolutely unavoidable.
- Prefer changes only in engine, scripts, tests, evaluation, and docs.
- Do not fake historical metrics.
- Do not call any threshold a plagiarism-guilt threshold. It is a review threshold only.

Your tasks
1. Inspect the actual repo and identify the current C-engine entry point, score outputs, and any existing test/evaluation harness.
2. Fill out `docs/REPO_ANALYSIS_TEMPLATE.md` inside the repo or copy its structure into a new repo-local analysis file.
3. Integrate a repo-local evaluation runner that can consume `benchmark_pairs.json`.
4. Treat zip archives as the primary fixture format because the SRS supports single-file or zip student uploads and zip templates.
5. Support template subtraction whenever the engine already has that capability; if missing, document the gap and add the smallest clean hook possible.
6. Add threshold sweep output for confusion matrix, precision, recall, false positive rate, false negative rate, and per-assignment breakdown.
7. Keep labels review-oriented: `should_flag_for_review=true/false`.
8. Keep all benchmark claims honest: this package is synthetic and provisional.

Data semantics
- Positive labeled pairs are intended to be flagged for human review.
- Negative labeled pairs are intended not to be flagged.
- Borderline negatives should help calibrate threshold conservatively.
- Cross-assignment negatives are sanity checks.

Required outputs
- repo-local evaluation runner/CLI
- machine-readable metric outputs
- short README with exact run commands
- exact file list changed
- statement of what is valid now vs what still requires anonymized historical data
