#include "template.h"

static void* thread_entry(void* raw) {
    WorkChunk* piece = (WorkChunk*) raw;
    int count = 0;
    for (int value = piece->start; value <= piece->end; ++value) {
        if (value >= 2) {
            int ok = 1;
            for (int trial = 2; trial * trial <= value; ++trial) {
                if (value % trial == 0) {
                    ok = 0;
                    break;
                }
            }
            if (ok) {
                count += 1;
            }
        }
    }
    piece->partial_count = count;
    return NULL;
}

int main(int argc, char** argv) {
    if (argc != 4) {
        print_usage();
        return 1;
    }

    int low = atoi(argv[1]);
    int high = atoi(argv[2]);
    int worker_count = atoi(argv[3]);
    if (worker_count < 1 || high < low) return 2;

    pthread_t handles[16];
    WorkChunk ranges[16];
    int span = (high - low + 1) / worker_count;
    int left = low;
    int answer = 0;

    for (int i = 0; i < worker_count; ++i) {
        ranges[i].start = left;
        ranges[i].end = (i == worker_count - 1) ? high : (left + span - 1);
        ranges[i].partial_count = 0;
        left = ranges[i].end + 1;
        pthread_create(&handles[i], NULL, thread_entry, &ranges[i]);
    }

    for (int i = 0; i < worker_count; ++i) {
        pthread_join(handles[i], NULL);
        answer += ranges[i].partial_count;
    }

    printf("%d\n", answer);
    return 0;
}
