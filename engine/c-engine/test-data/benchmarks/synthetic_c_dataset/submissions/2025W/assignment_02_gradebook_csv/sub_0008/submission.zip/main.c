#include "template.h"

double compute_weighted_average(int* marks, int n);

int main(void) {
    StudentRecord row;
    print_header();
    while (scanf("%63[^,],%d,%d,%d,%d\n",
                 row.name,
                 &row.marks[0],
                 &row.marks[1],
                 &row.marks[2],
                 &row.marks[3]) == 5) {
        row.average = compute_weighted_average(row.marks, 4);
        printf("%s,%.2f\n", row.name, row.average);
    }
    return 0;
}
