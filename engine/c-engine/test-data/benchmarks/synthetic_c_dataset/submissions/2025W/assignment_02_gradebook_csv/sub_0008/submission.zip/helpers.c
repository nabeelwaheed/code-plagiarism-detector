#include "template.h"

double compute_weighted_average(int* marks, int n) {
    int weights[4] = {1, 2, 2, 3};
    int weighted = 0;
    int denom = 0;
    for (int i = 0; i < n; ++i) {
        weighted += marks[i] * weights[i];
        denom += weights[i];
    }
    return (double)weighted / (double)denom;
}
